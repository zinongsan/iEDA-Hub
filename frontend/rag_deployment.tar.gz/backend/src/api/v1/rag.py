"""
RAG相关的API路由
提供AI问答和讲义生成接口
"""
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field
from typing import Optional, Literal

# 延迟导入RAG服务（避免启动时加载）
_rag_service = None

def get_rag_service():
    """获取RAG服务单例"""
    global _rag_service
    if _rag_service is None:
        from ...services.rag_service import RAGService
        # 初始化RAG服务
        _rag_service = RAGService(
            knowledge_base_dir="./knowledge_base",
            retrieval_mode="auto",  # 自动选择检索方式
            embedding_type="zhipu"
        )
    return _rag_service


router = APIRouter()


# ============================================
# 请求/响应模型
# ============================================

class QARequest(BaseModel):
    """AI问答请求"""
    question: str = Field(..., min_length=1, max_length=500, description="用户问题")
    max_tokens: int = Field(500, ge=50, le=2000, description="最大输出token数")
    temperature: float = Field(0.7, ge=0, le=1, description="生成温度")


class QAResponse(BaseModel):
    """AI问答响应"""
    answer: str = Field(..., description="AI生成的答案")
    sources: list[str] = Field(..., description="参考来源")
    tokens: dict = Field(..., description="token统计")
    cost: float = Field(..., description="成本（人民币）")
    retrieval_mode: str = Field(..., description="检索模式 keyword/vector")


class LectureRequest(BaseModel):
    """讲义生成请求"""
    topic: str = Field(..., min_length=1, max_length=200, description="讲义主题")
    detail_level: Literal["simple", "medium", "detailed"] = Field(
        "medium",
        description="详细程度：simple简明/medium中等/detailed详细"
    )


class LectureResponse(BaseModel):
    """讲义生成响应"""
    title: str = Field(..., description="讲义标题")
    content: str = Field(..., description="讲义内容（Markdown格式）")
    sources: list[str] = Field(..., description="参考来源")
    tokens: dict = Field(..., description="token统计")
    cost: float = Field(..., description="成本（人民币）")


# ============================================
# API端点
# ============================================

@router.post("/qa", response_model=QAResponse, summary="AI问答")
async def qa(request: QARequest):
    """
    AI问答接口

    基于RAG（检索增强生成）技术，从知识库中检索相关内容后生成答案。

    **使用场景**：
    - 讲义页面的AI答疑功能
    - 学生学习过程中的实时问答

    **示例请求**：
    ```json
    {
      "question": "什么是EDA工具？",
      "max_tokens": 500,
      "temperature": 0.7
    }
    ```

    **返回**：
    - answer: AI生成的答案
    - sources: 参考来源片段
    - tokens: token消耗统计
    - cost: 本次调用成本
    - retrieval_mode: 使用的检索模式
    """
    try:
        rag = get_rag_service()

        result = rag.generate_answer(
            question=request.question,
            max_tokens=request.max_tokens,
            temperature=request.temperature
        )

        return QAResponse(**result)

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"AI问答失败: {str(e)}"
        )


@router.post("/lectures/generate", response_model=LectureResponse, summary="生成讲义")
async def generate_lecture(request: LectureRequest):
    """
    生成讲义接口

    基于RAG技术，从知识库检索相关内容后生成结构化讲义。

    **使用场景**：
    - 自动生成课程讲义
    - 快速制作教学材料

    **示例请求**：
    ```json
    {
      "topic": "数字电路设计基础",
      "detail_level": "medium"
    }
    ```

    **detail_level说明**：
    - simple: 简明扼要，适合快速了解
    - medium: 中等详细，包含关键概念和示例
    - detailed: 详细深入，包含原理、示例和扩展内容

    **返回**：
    - title: 讲义标题
    - content: 讲义内容（Markdown格式）
    - sources: 参考来源
    - tokens: token消耗
    - cost: 成本
    """
    try:
        rag = get_rag_service()

        result = rag.generate_lecture(
            topic=request.topic,
            detail_level=request.detail_level
        )

        return LectureResponse(**result)

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"讲义生成失败: {str(e)}"
        )


@router.get("/status", summary="RAG服务状态")
async def get_status():
    """
    获取RAG服务状态

    **返回**：
    - status: 服务状态
    - retrieval_mode: 当前检索模式
    - knowledge_base_size: 知识库大小
    """
    try:
        rag = get_rag_service()

        return {
            "status": "ok",
            "retrieval_mode": "vector" if hasattr(rag.retriever, 'vectorstore') else "keyword",
            "knowledge_base_size": len(rag.chunks),
            "chunk_size": rag.chunk_size,
            "chunk_overlap": rag.chunk_overlap
        }

    except Exception as e:
        return {
            "status": "error",
            "error": str(e)
        }


class SearchRequest(BaseModel):
    """搜索请求"""
    query: str = Field(..., min_length=1, max_length=200, description="搜索查询")
    k: int = Field(3, ge=1, le=10, description="返回结果数量")


@router.post("/search", summary="搜索知识库")
async def search(request: SearchRequest):
    """
    搜索知识库接口（用于调试）

    直接搜索知识库，返回相关文档片段。

    **示例请求**：
    ```
    POST /api/v1/rag/search?query=EDA工具&k=3
    ```

    **返回**：
    - results: 搜索结果列表
    - count: 结果数量
    - retrieval_mode: 检索模式
    """
    try:
        rag = get_rag_service()

        docs = rag.search(request.query, k=request.k)

        return {
            "results": [
                {
                    "content": doc.page_content,
                    "metadata": doc.metadata
                }
                for doc in docs
            ],
            "count": len(docs),
            "retrieval_mode": "vector" if hasattr(rag.retriever, 'vectorstore') else "keyword"
        }

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"搜索失败: {str(e)}"
        )
